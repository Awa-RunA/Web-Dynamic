﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinalProjectv2.Migrations
{
    /// <inheritdoc />
    public partial class UpdateData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "CrochetProducts",
                keyColumn: "ProductId",
                keyValue: 1,
                column: "ImagePath",
                value: "/images/TestProduct.png");

            migrationBuilder.UpdateData(
                table: "CrochetProducts",
                keyColumn: "ProductId",
                keyValue: 2,
                column: "ImagePath",
                value: "/images/StuffedAnimalSweater.png");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "CrochetProducts",
                keyColumn: "ProductId",
                keyValue: 1,
                column: "ImagePath",
                value: "/images/TestProduct.jpeg");

            migrationBuilder.UpdateData(
                table: "CrochetProducts",
                keyColumn: "ProductId",
                keyValue: 2,
                column: "ImagePath",
                value: "/images/StuffedAnimalSweater.jpeg");
        }
    }
}
