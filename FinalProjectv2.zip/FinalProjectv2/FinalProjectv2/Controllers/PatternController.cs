﻿using Microsoft.AspNetCore.Mvc;

namespace FinalProjectv2.Controllers
{
    public class PatternController : Controller
    {
        public IActionResult Index()
        {
            return View("Views/Pattern/Index.cshtml");
        }
    }
}
