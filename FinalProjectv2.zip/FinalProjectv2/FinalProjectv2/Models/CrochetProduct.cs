﻿using System.ComponentModel.DataAnnotations;
namespace FinalProjectv2.Models
{
    public class CrochetProduct
    {
        [Key]
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty; 
        public String ProductDescription { get; set; } = String.Empty;
        public String ProductCategory { get; set; } = String.Empty;
        public double ProductPrice { get; set; }    
        public int ProductQuantity { get; set; }
        public DateOnly AddedDate { get; set; }
        public string AvailabilityStatus { get; set; } = string.Empty;
        public string ImagePath { get; set; } = string.Empty;
    }
}
