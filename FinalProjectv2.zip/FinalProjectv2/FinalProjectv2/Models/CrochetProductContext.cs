﻿using Microsoft.EntityFrameworkCore;
namespace FinalProjectv2.Models
{
    public class CrochetProductContext : DbContext
    {
        public CrochetProductContext(DbContextOptions<CrochetProductContext> options)
            : base(options)
        { }

        public DbSet<CrochetProduct> CrochetProducts { get; set; } = null;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CrochetProduct>().HasData(

                new CrochetProduct
                {
                    ProductId = 1,
                    ProductName = "Zebra Plushie",
                    ProductDescription = "Zebra Plsuhie. Pattern can be found: https://www.jenhayescreations.com/small-animal-collection-crochet-zebra/ ",
                    ProductCategory = "Plusies",
                    ProductPrice = 20.00,
                    ProductQuantity = 1,
                    ImagePath = "/images/TestProduct.png",
                    AddedDate = new DateOnly(2024, 03, 30),
                    AvailabilityStatus = "Available"

                },
                new CrochetProduct
                {
                    ProductId = 2,
                    ProductName = "Stuffed Animal Sweater",
                    ProductDescription = "Gray sweater with teal colar for Build a Bear or stuffed animal.",
                    ProductPrice = 15.00,
                    ProductQuantity = 1,
                    ProductCategory = "Plushies",
                    ImagePath = "/images/StuffedAnimalSweater.png",
                    AddedDate = new DateOnly(202, 03, 30),
                    AvailabilityStatus = "Not Available"
                }

                );
        }
    }
}

