﻿using Microsoft.AspNetCore.Mvc;

namespace FinalProjectv2.Controllers
{
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            return View("Views/Cart/Index.cshtml");
        }
    }
}
