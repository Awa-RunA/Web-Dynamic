﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileSystemGlobbing.Internal;
using FinalProjectv2.Models;

namespace FinalProjectv2.Controllers
{
    public class ProductController : Controller
    {
        private CrochetProductContext context { get; set; }
        public ProductController(CrochetProductContext ctx) => context = ctx;

        public IActionResult Index()
        {
            var crochet = context.CrochetProducts.OrderBy(m=>m.ProductId).ToList();
            return View("Views/Product/Index.cshtml", crochet);
        }
        public IActionResult Details(int id)
        {
            var crochet = context.CrochetProducts.FirstOrDefault(m => m.ProductId == id);
            if (crochet == null)
            {
                return NotFound();
            }
            return View(crochet);
        }
        public IActionResult Accessories()
        {
            return View("Views/Product/Accessories.cshtml");
        }
    }
}
