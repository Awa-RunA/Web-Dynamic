﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinalProjectv2.Migrations.Cart
{
    /// <inheritdoc />
    public partial class CartCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CustomerCart",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductCategory = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductPrice = table.Column<double>(type: "float", nullable: false),
                    ProductQuantity = table.Column<int>(type: "int", nullable: false),
                    ImagePath = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerCart", x => x.ProductId);
                });

            migrationBuilder.InsertData(
                table: "CustomerCart",
                columns: new[] { "ProductId", "ImagePath", "ProductCategory", "ProductDescription", "ProductName", "ProductPrice", "ProductQuantity" },
                values: new object[] { 1, "/images/TestProduct.png", "Test", "Test", "Test", 15.0, 1 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CustomerCart");
        }
    }
}
