﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace FinalProjectv2.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CrochetProducts",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductCategory = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductPrice = table.Column<double>(type: "float", nullable: false),
                    ProductQuantity = table.Column<int>(type: "int", nullable: false),
                    AddedDate = table.Column<DateOnly>(type: "date", nullable: false),
                    AvailabilityStatus = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ImagePath = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CrochetProducts", x => x.ProductId);
                });

            migrationBuilder.InsertData(
                table: "CrochetProducts",
                columns: new[] { "ProductId", "AddedDate", "AvailabilityStatus", "ImagePath", "ProductCategory", "ProductDescription", "ProductName", "ProductPrice", "ProductQuantity" },
                values: new object[,]
                {
                    { 1, new DateOnly(2024, 3, 30), "Available", "/images/TestProduct.jpeg", "Plusies", "Zebra Plsuhie. Pattern can be found: https://www.jenhayescreations.com/small-animal-collection-crochet-zebra/ ", "Zebra Plushie", 20.0, 1 },
                    { 2, new DateOnly(202, 3, 30), "Not Available", "/images/StuffedAnimalSweater.jpeg", "Plushies", "Gray sweater with teal colar for Build a Bear or stuffed animal.", "Stuffed Animal Sweater", 15.0, 1 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CrochetProducts");
        }
    }
}
