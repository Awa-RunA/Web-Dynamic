﻿using Microsoft.EntityFrameworkCore;
namespace FinalProjectv2.Models
{
    public class CartContext: DbContext
    {
        public CartContext(DbContextOptions<CartContext> options) 
            : base() 
        { }

        public DbSet<Cart> CustomerCart { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("CartContext");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Cart>().HasData(
                new Cart
                {
                   ProductId = 1,
                   ProductName = "Test",
                   ProductDescription = "Test",
                   ProductCategory = "Test",
                   ProductPrice = 15.00,
                   ProductQuantity = 1,
                   ImagePath = "/images/TestProduct.png"
                }
                );
        }
    }
}
