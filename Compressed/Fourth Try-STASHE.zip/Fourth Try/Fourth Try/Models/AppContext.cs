﻿// AppContext.cs
using Fourth_Try.Models;
using Microsoft.EntityFrameworkCore;

public class AppContext : DbContext
{
    public DbSet<FAQ> FAQs { get; set; }
    public DbSet<Topic> Topics { get; set; }
    public DbSet<Category> Categories { get; set; }

    public AppContext(DbContextOptions<AppContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Topic>().HasData(
            new Topic { Id = 1, Name = "Bootstrap" },
            new Topic { Id = 2, Name = "C#" },
            new Topic { Id = 3, Name = "JavaScript" }
        );

        modelBuilder.Entity<Category>().HasData(
            new Category { Id = 1, Name = "General" },
            new Category { Id = 2, Name = "History" }
        );

        modelBuilder.Entity<FAQ>().HasData(
            new FAQ
            {
                Id=1,
                Question="What is BootStrap?",
                Answer="A CSS framework for creating responsive web apps for multiple screen sizes.",
                CategoryId=1,
                TopicId=1
            },
            new FAQ
            {
                Id=2,
                Question="What is C#?",
                Answer="A general purpose object oriented language that uses a consise, Jaba-like syntax",
                CategoryId=1,
                TopicId=2
            },
            new FAQ
            {
                Id=3,
                Question="What is Javascript?",
                Answer="A general purpose scripting language that executes in a web browser",
                CategoryId=1,
                TopicId=3
            },
            new FAQ
            {
                Id=4, 
                Question="When was Bootstrap first released?",
                Answer="In 2011.",
                CategoryId=2,
                TopicId=1
            });
    }
}
