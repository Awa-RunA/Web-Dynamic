﻿using System.ComponentModel;

namespace Fourth_Try.Models
{
    public class FAQ
    {
        public int Id { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public int TopicId { get; set; }
        public Topic Topic { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}
