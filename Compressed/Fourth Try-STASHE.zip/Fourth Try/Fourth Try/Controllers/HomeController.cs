using Fourth_Try.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Fourth_Try.Controllers
{
    public class HomeController : Controller
    {
       private AppContext context { get; set; }
        

        public HomeController(AppContext ctx) => context = ctx;
        public IActionResult Index()
        {
            var faqs = context.FAQs.OrderBy(m => m.Id).ToList();
            return View(faqs);
        }

       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
