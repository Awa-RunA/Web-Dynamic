﻿using Microsoft.EntityFrameworkCore;
namespace Assignement4_1.Models
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) 
            : base(options)
        { }
        public DbSet<Product> Products { get; set; } = null;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ID =1,
                    Code="TRNY10",
                    Name = "Tournament MAster 1.0",
                    Price = 4.99,
                    ReleaseDate = "12/1/2018"
                },
                new Product
                {
                    ID =2,
                    Code ="LEAG10",
                    Name ="League Sceduler 1.0",
                    Price = 4.99,
                    ReleaseDate = "5/1/2019"
                },
                new Product
                {
                    ID =3,
                    Code ="LEAGD10",
                    Name="League Scheduler Deluxe 1.0",
                    Price = 7.99,
                    ReleaseDate ="8/1/2019"
                },
                new Product
                {
                    ID =4,
                    Code ="DRAFT10",
                    Name ="Draft MAnager 1.0",
                    Price =4.99,
                    ReleaseDate="2/1/2020"
                },
                new Product
                {
                    ID = 5,
                    Code ="TEAM10",
                    Name="Team Manager 1.0",
                    Price = 4.99,
                    ReleaseDate="5/1/2020"
                },
                new Product
                {
                    ID = 6,
                    Code ="TRNY20",
                    Name="Tournament Master 2.0",
                    Price=5.99,
                    ReleaseDate="2/15/2021"
                },
                new Product
                {
                    ID = 7,
                    Code="DRAFT20",
                    Name="Draft Manager 2.0",
                    Price=5.99,
                    ReleaseDate = "7/15/2022"
                });
        }
    }
}
