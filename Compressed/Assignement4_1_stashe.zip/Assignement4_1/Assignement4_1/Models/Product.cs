﻿using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System.ComponentModel.DataAnnotations;
namespace Assignement4_1.Models
{
    public class Product
    {
        [Required(ErrorMessage = "Please Enter a code")]
        public string Code { get; set; } = String.Empty;

        [Required (ErrorMessage ="Please Enter a name")]
        public string Name { get; set; } = String.Empty;

        [Required(ErrorMessage ="Please Enter a Price")]
        [Range(0,100, ErrorMessage ="Price shold be between $0 and $100")]
        public double? Price { get; set; }

        [Required(ErrorMessage = "Please Enter a ReleaseDate")]
        public string ReleaseDate { get; set; } = string.Empty;

        public int ID { get; set; }


    }
}
