﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Assignement4_1.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<double>(type: "float", nullable: false),
                    ReleaseDate = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ID);
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ID", "Code", "Name", "Price", "ReleaseDate" },
                values: new object[,]
                {
                    { 1, "TRNY10", "Tournament MAster 1.0", 4.9900000000000002, "12/1/2018" },
                    { 2, "LEAG10", "League Sceduler 1.0", 4.9900000000000002, "5/1/2019" },
                    { 3, "LEAGD10", "League Scheduler Deluxe 1.0", 7.9900000000000002, "8/1/2019" },
                    { 4, "DRAFT10", "Draft MAnager 1.0", 4.9900000000000002, "2/1/2020" },
                    { 5, "TEAM10", "Team Manager 1.0", 4.9900000000000002, "5/1/2020" },
                    { 6, "TRNY20", "Tournament Master 2.0", 5.9900000000000002, "2/15/2021" },
                    { 7, "DRAFT20", "Draft Manager 2.0", 5.9900000000000002, "7/15/2022" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
