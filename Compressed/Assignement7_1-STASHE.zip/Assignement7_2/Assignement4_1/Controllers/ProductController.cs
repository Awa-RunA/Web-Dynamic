﻿using Microsoft.AspNetCore.Mvc;
using Assignement4_1.Models;

namespace Assignement4_1.Controllers
{
    public class ProductController : Controller
    {
       private ProductContext context {  get; set; }

        public ProductController(ProductContext ctx) => context = ctx;
        public IActionResult Product()
        {

            return View();
        }
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("Edit", new Product());
        }
        [HttpGet]
        public IActionResult Edit(int ID)
        {
            ViewBag.Action = "Edits";
            var product = context.Products.Find(ID);
            return View(product);
        }

        [HttpPost]
        public IActionResult Edit(Product product)
        {
            if(ModelState.IsValid)
            {
                if(product.ID == 0)
                    context.Products.Add(product);
                else
                    context.Products.Update(product);
                context.SaveChanges();  
                return RedirectToAction("Edit", "Product");

            }
            else
            {
                ViewBag.Action = (product.ID == 0) ? "Add" : "Edit";
                return View(product);
            }
        }
        [HttpGet]
        public IActionResult Delete(int ID)
        {
            var product = context.Products.Find(ID);
            return View(product);
        }
        [HttpPost]
        public IActionResult Delete(Product product)
        {
            context.Products.Remove(product);
            context.SaveChanges();
            return RedirectToAction("Product");
        }
    }
}
