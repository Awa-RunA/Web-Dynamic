using Assignement4_1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;


namespace Assignement4_1.Controllers
{
    public class HomeController : Controller

    {
        private ProductContext context {  get; set; }
        public HomeController(ProductContext ctx) => context = ctx;
        public IActionResult Index()
        {
            
            return View();
        }

        public IActionResult Products()
        {
            var product = context.Products.OrderBy(m => m.Name).ToList();
            return View(product);
        }
        
        public IActionResult Customers()
        {
            return View();
        } 
        public IActionResult Tech()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        
    }
}
