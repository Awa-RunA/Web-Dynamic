﻿using Microsoft.AspNetCore.Mvc;

namespace Assignement4_1.Controllers
{
    public class TechnController : Controller
    {
        public IActionResult Tech()
        {
            return View();
        }
    }
}
