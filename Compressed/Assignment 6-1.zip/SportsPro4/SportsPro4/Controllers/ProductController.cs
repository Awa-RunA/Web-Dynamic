﻿using Microsoft.AspNetCore.Mvc;
using SportsPro4.Models;
using System.Net.WebSockets;

namespace SportsPro4.Controllers
{
    public class ProductController : Controller
    {
        private ProductContext context { get; set; }
        public ProductController(ProductContext ctx) => context = ctx;

        [Route("product")]
        public IActionResult Index()
        {
            var product = context.Productss.OrderBy(m => m.ReleaseDt).ToList();
            return View("Views/Product/Index.cshtml", product);
        }

        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("Edit", new Product());
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            ViewBag.Action = "Edit";
            var product = context.Productss.Find(Id);
            return View(product);
        }

        [HttpPost]
        public IActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                if(product.Id == 0)
                {
                    context.Productss.Add(product);
                    return View("Edit");
                    
                }
                else
                {
                    context.Productss.Update(product);
                    context.SaveChanges();
                    return RedirectToAction("Index", "Product");
                }
            }
            else
            {
                ViewBag.Action = (product.Id == 0) ? "Add" : "Edit";
                return View(product);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var product = context.Productss.Find(id);
            return View(product);
        }

        [HttpPost]
        public IActionResult Delete(Product product)
        {
            context.Productss.Remove(product);
            context.SaveChanges();
            return RedirectToAction("Index", "Product");
        }
    }
}
