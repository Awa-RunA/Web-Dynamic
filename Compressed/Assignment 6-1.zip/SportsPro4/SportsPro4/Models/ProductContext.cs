﻿using Microsoft.EntityFrameworkCore;
namespace SportsPro4.Models
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) 
            : base(options)
        {}

        public DbSet<Product> Productss { get; set;}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                   new Product
                   {
                       Id = 1,
                       Code = "TRNY10",
                       Name = "Tournament Master 1.0",
                       Price = 4.99,
                       ReleaseDt = new DateTime(2018,12,1)
                   },
                   new Product
                   {
                       Id = 2,
                       Code = "LEAG10",
                       Name = "Legue Scheduler 1.0",
                       Price = 4.99,
                       ReleaseDt = new DateTime(2019,5,1) 
                   },
                   new Product
                   {
                       Id = 3,
                       Code = "LEAGD10",
                       Name = "League Scheduler Deluxe 1.0",
                       Price = 7.99,
                       ReleaseDt = new DateTime(2019,8,1) 
                   },
                   new Product
                   {
                       Id = 4,
                       Code = "DRAFT",
                       Name = "Draft Msnsger 1.0",
                       Price = 4.99,
                       ReleaseDt = new DateTime(2020,2,1)
                   },
                   new Product
                   {
                       Id = 5,
                       Code = "TEAM10",
                       Name = "Team Manager 1.0",
                       Price = 4.99,
                       ReleaseDt = new DateTime(2020,5,1)
                   },
                   new Product
                   {
                       Id = 6,
                       Code = "TRNY20",
                       Name = "Tournament Master 2.0",
                       Price = 5.99,
                       ReleaseDt =  new DateTime(2021,2,15)
                   },
                   new Product
                   {
                       Id = 7,
                       Code = "DRAFT20",
                       Name = "Draft Manager 2.0",
                       Price = 5.99,
                       ReleaseDt = new DateTime(2022,7,15)
                   }
               );
        }
    }
}
