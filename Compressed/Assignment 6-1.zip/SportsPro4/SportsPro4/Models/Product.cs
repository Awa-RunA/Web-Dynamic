﻿using System.ComponentModel.DataAnnotations;
namespace SportsPro4.Models
{
    public class Product
    {
        public int Id {  get; set; }
        [Required(ErrorMessage="Product Code is required!")]
        public string Code { get; set; }
        [Required (ErrorMessage="Product Name is required!")]
        public string Name { get; set; }
        [Required(ErrorMessage ="Product price is required!")]
        public double Price { get; set; }
        [Required(ErrorMessage ="Relases Date is reqired!")]
        public DateTime ReleaseDt { get; set; }
    }
}
